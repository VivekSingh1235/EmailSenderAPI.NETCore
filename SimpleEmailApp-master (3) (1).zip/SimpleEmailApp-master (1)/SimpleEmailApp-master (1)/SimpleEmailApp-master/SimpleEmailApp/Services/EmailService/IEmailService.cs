﻿
namespace SimpleEmailApp.Services.EmailService
{
    public interface IEmailService
    {
        void SendEmail(string? to, string? subject, string? body, EmailDto request);
        void SendEmail(string? to, string? subject, string? body, IFormFile attachment);
        void SendEmail(EmailDto request, IFormFile attachment);
    }
}
